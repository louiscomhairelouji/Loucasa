# LouCasa — loucasa.com

Two-page brand site: `index.html` (home) + `contact.html`. Fully self-contained —
logo, favicon and all six renders are embedded, so the pages preview and deploy
with zero extra setup. (Optimized copies also live in `assets/`.)

## Deploy (same flow as louenterprises.com)
1. Push this folder to a repo → import in Vercel (framework: **Other**). `vercel.json` gives clean URLs (`/contact`).
2. Vercel → Settings → Domains → add **loucasa.com** (+ www) and update DNS as prompted.
3. Google Search Console → add loucasa.com → submit `https://loucasa.com/sitemap.xml`.

## Imagery
- Hero + LouCasa Dubaï card: the Dubai render.
- Villa Saint-Raphaël card: kitchen render; “Inside the villa” gallery: salon,
  cuisine, salle de bain, escalier renders.
- `og.jpg` (link preview, 1200×630) generated from the Dubai render + white logo.
- Optional film hero: drop `assets/hero.mp4` and use the commented <video> snippet.

## Contact form
`contact.html` posts to Web3Forms. Create a free access key for
**info@loucasa.com** at https://web3forms.com and paste it into the
`access_key` hidden input. Until then, submitting opens the visitor's
email app pre-filled to info@loucasa.com — the page never breaks.

## Wired contacts
- Email: info@loucasa.com · Phone/WhatsApp: +33 7 86 41 05 57 (wa.me/33786410557)
- Instagram: @maisonloucasa (handle only — the brand is LouCasa)
- Both stays show “Reservations opening soon” with waitlist buttons.
